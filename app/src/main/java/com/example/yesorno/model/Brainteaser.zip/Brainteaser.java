package com.example.yesorno.model;

public class Brainteaser {

    private String name;
    private int brainteaserCategoryId;
    private int brainteaserId;
    private String description;
    private String answer;
    private String imgUrl;

    public int getBrainteaserId() {
        return brainteaserId;
    }

    public void setBrainteaserId(int brainteaserId) {
        this.brainteaserId = brainteaserId;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }


//    public static Brainteaser[][] brainteasers = new Brainteaser[][]{
//            {
//                    new Brainteaser(1, "Роковая обезьянка", "Пять человек погибли из-за игрушечной обезьянки. Как такое произошло?", "Они ехали в легковой машине, на стекле которой болталась игрушечная обезьянка. Из-за этой обезьянки водитель не успел заметить выехавший из-за поворота грузовик.",
//                            "http://cartoon-monkeys.clipartonline.net/_/rsrc/1396350212880/funny-baby-monkeys/cartoon_monkey_image_0002.png"),
//                    new Brainteaser(1, "Деревенский дурачок", "Люди, приезжавшие в живописную горную деревушку, часто удивлялись местному дурачку. Когда ему предлагали выбор между блестящей 50-центовой монетой и мятой пятидолларовой купюрой, он всегда выбирал монету, хотя она стоит вдесятеро меньше купюры. Почему он никогда не выбирал купюру?",
//                            "«Дурачок» был не так глуп: он понимал, что, пока он будет выбирать 50-центовую монету, люди будут предлагать ему выбор, а если он выберет пятидолларовую купюру, предложения выбора прекратятся, и он не будет получать ничего.","https://cdn3.iconfinder.com/data/icons/minimal-utility/512/man.png"),
//            }
//    };

    public Brainteaser(int brainteaserCategoryId, String name, String description, String answer, String imgUrl) {
        this.brainteaserCategoryId = brainteaserCategoryId;
        this.name = name;
        this.description = description;
        this.answer = answer;
        this.imgUrl = imgUrl;

    }

    public void setBrainteaserCategoryId(int brainteaserCategoryId) {
        this.brainteaserCategoryId = brainteaserCategoryId;
    }

    public void setBrainName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getBrainteaserCategoryId() {
        return brainteaserCategoryId;
    }

    public String getBrainName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getAnswer() {
        return answer;
    }

    @Override
    public String toString() {
        return name;
    }
}
